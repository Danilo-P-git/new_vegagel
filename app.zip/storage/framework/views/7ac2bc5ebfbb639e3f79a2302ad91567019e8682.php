

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if($products->count()): ?>
    <table>
        <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sector.settore', 'Settore'));?></th>
                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sector.scaffale', 'scaffale'));?></th>
                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('codice_prodotto', 'Codice Prodotto'));?></th>
                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('codice_stock', 'Codice stock'));?></th>

                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', 'Nome Prodotto'));?></th>
                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Arrivato il'));?></th>
                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('updated_at', 'Spostato il'));?></th>
                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('data_di_scadenza', 'data di scadenza'));?></th>
                <th scope="col">Azioni</th>

              </tr>
            </thead>
            <tbody>
              
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($product->sector->settore); ?></td>
                    <td><?php echo e($product->sector->scaffale); ?></td>
                    <td><?php echo e($product->codice_prodotto); ?></td>
                    <td><?php echo e($product->codice_stock); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->created_at); ?></td>
                    <td><?php echo e($product->updated_at); ?></td>
                    <td><?php echo e($product->data_di_scadenza); ?></td>
                    <td>
                        <a href="<?php echo e(route("worker.edit", $product->id)); ?>" class="btn btn-primary rounded"><i class="fas fa-edit"></i></a>

                        <a href="<?php echo e(route("worker.show", $product->id)); ?>" class="btn btn-secondary mt-1"><i class="fas fa-eye"></i></a>
                    </td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
             
            </tbody>
          </table>
          
    </table>

    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danil\OneDrive\Desktop\progetti_kemedia\new_vegagel\resources\views/worker/search.blade.php ENDPATH**/ ?>