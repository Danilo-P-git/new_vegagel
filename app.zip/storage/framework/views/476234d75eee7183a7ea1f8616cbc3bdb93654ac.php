

<?php $__env->startSection('content'); ?>

<div class="manutenzione">
    <div class="manutenzione-inside m-auto">
        <h1>Ci dispiace per l'incoveniente...</h1>
        <p class="inside-paragraph">In questo momento la pagina è in fase di manutenzione vi preghiamo di riprovare più tardi</p>
    </div>
</div>





            
            
            
            
        



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danil\OneDrive\Desktop\progetti_kemedia\new_vegagel\resources\views/welcome.blade.php ENDPATH**/ ?>