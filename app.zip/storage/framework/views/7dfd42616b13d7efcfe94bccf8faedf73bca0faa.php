

<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="<?php echo e(route('worker.update', $product->id)); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('put'); ?>
      <div class="card">
        
        <div class="card-body">
        
          <div class="row">
        
            <div class="col-xs-12 col-sm-12 col-md-6">
        
              <div id="interactive" class="viewport"></div>
        
            </div>
        
            <div class="col-xs-12 col-sm-12 col-md-6">
        
              <div id="result_strip">
        
              </div>
        
            </div>
        
          </div>
        
        </div>
      
      </div>
    
      

  <div class="form-row">
    <div class="form-group col-md-5 col-4">
      
      <label for="codice_prodotto">codice prodotto</label>
      <input name="codice_prodotto" type="number" id="codice_prodotto" class="form-control code-scanner" value="<?php echo e(old("codice_prodotto") ? old("codice_prodotto") : $product->codice_prodotto); ?>">
      <?php $__errorArgs = ['codice_prodotto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group col-md-5 col-4">
      <label for="codice_stock">codice stock</label>
      <input name="codice_stock" type="number" id="codice_stock" class="form-control code-scanner" value="<?php echo e(old("codice_stock") ? old("codice_stock") : $product->codice_stock); ?>">
      <?php $__errorArgs = ['codice_stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group col-md-2 col-4">
      
      <label for="lotto">Lotto</label>
      <input name="lotto" type="number" id="lotto" class="form-control code-scanner" value="<?php echo e(old("lotto") ? old("lotto") : $product->lotto); ?>">
      <?php $__errorArgs = ['lotto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    
  </div>

      

  <div class="form-row">

    <div class="form-group col-md-4 col-4">
      <label for="scaffale">scaffale</label>
      <input name="scaffale" type="text"  id="scaffale" class="form-control" value="<?php echo e(old("scaffale") ? old("scaffale") : $product->sector->scaffale); ?>">
      <?php $__errorArgs = ['scaffale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-4 col-4">
      <label for="quantita_rimanente">Quantità totale</label>
      <input name="quantita_rimanente" type="number"  id="quantita_rimanente" class="form-control" value="<?php echo e(old("quantita_rimanente") ? old("quantita_rimanente") : $product->sector->quantita_rimanente); ?>"> 
      <?php $__errorArgs = ['quantita_rimanente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group col-md-4 col-4">
      <label for="data_di_scadenza">data_di_scadenza</label>
      <input name="data_di_scadenza" type="date" id="data_di_scadenza" class="form-control" value="<?php echo e(old("data_di_scadenza") ? old("data_di_scadenza") : $product->data_di_scadenza); ?>" >
      <?php $__errorArgs = ['data_di_scadenza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>
      

      

  <div class="form-row">

    <div class="form-group col-md-4 col-4">
      <label for="name">name</label>
      <input name="name" type="text" class="form-control" id="name" value="<?php echo e(old("name") ? old("name") : $product->name); ?>">
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-4 col-4">
      <label for="description">description</label>
      <input name="description" type="text" class="form-control" id="description" value="<?php echo e(old("description") ? old("description") : $product->description); ?>">
      <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group col-md-4 col-4">
      
      <label for="quantita_al_cartone">Quantità al cartone</label>
      <input name="quantita_al_cartone" type="number" id="quantita_al_cartone" class="form-control code-scanner" value="<?php echo e(old("quantita_al_cartone") ? old("quantita_al_cartone") : $product->sector->quantita_al_cartone); ?>">
      <?php $__errorArgs = ['quantita_al_cartone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>

    


    

  <div class="form-row">
    <div class="form-group col-md-4 col-4">
      
      <label for="prezzo_al_pezzo">Prezzo al pezzo</label>
      <input name="prezzo_al_pezzo" type="number" id="prezzo_al_pezzo" class="form-control code-scanner" value="<?php echo e(old("prezzo_al_pezzo") ? old("prezzo_al_pezzo") : $product->prezzo_al_pezzo); ?>">
      <?php $__errorArgs = ['prezzo_al_pezzo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group col-md-4 col-4">
      <label for="prezzo_al_kg">Prezzo al kg</label>
      <input name="prezzo_al_kg" type="number" step=0.01 class="form-control" id="prezzo_al_kg" value="<?php echo e(old("prezzo_al_kg") ? old("prezzo_al_kg") : $product->prezzo_al_kg); ?>">
      <?php $__errorArgs = ['prezzo_al_kg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <div class="form-group col-md-4 col-4">
      <label for="settore">settore</label>
      <input name="settore" type="text" class="form-control" id="settore" value="<?php echo e(old("settore") ? old("settore") : $product->sector->settore); ?>">
      <?php $__errorArgs = ['settore'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>

  <button type="submit" class="btn btn-primary">Sposta</button>
  </form>
</div>


  <script type="text/javascript">

   $("form").keydown(function (e) {
       if (e.keyCode == 13) {
           e.preventDefault();
           return false;
       }
   });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danil\OneDrive\Desktop\progetti_kemedia\new_vegagel\resources\views/worker/edit.blade.php ENDPATH**/ ?>