

<?php $__env->startSection('content'); ?>


<div class="container d-flex flex-wrap flex-column">
    <h2 class="mx-auto my-5">
        Cerca il tuo prodotto
    </h2>

    <div class="d-flex mx-auto my-3">

        <form action="/worker/search" method="POST" role="search">
            <?php echo e(csrf_field()); ?>

            <div class="input-group">
                <input type="text" class="form-control" name="q"
                    placeholder="Cerca per codice prodotto"> <span class="input-group-btn">
                    <button type="submit" class="btn btn-default">
                        <span class="">Cerca</span>
                    </button>
                </span>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danil\OneDrive\Desktop\progetti_kemedia\new_vegagel\resources\views/worker/index.blade.php ENDPATH**/ ?>