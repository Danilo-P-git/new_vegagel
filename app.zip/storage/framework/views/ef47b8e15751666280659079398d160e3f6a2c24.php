

<?php $__env->startSection('content'); ?>

<div class="container">

    
    <h2 class="text-align-center"><?php echo e($product->name); ?></h2>

    <p><?php echo e($product->codice_prodotto); ?></p>

    <p><?php echo e($product->codice_stock); ?></p>

    <p><?php echo e($sector->settore); ?></p>
    <p><?php echo e($sector->scaffale); ?></p>
    <p><?php echo e($sector->quantita_rimanente); ?></p>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danil\OneDrive\Desktop\progetti_kemedia\new_vegagel\resources\views/worker/show.blade.php ENDPATH**/ ?>