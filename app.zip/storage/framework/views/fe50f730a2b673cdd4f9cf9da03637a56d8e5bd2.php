

<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
      <div class="col d-flex">
          <a class="btn  btn_menu m-auto d-flex" href="<?php echo e(route("worker.create")); ?>"><span class="m-auto">Scarico merci</span></a>

      </div>
      <div class="col">
        <a class="btn  btn_menu m-auto d-flex" href="<?php echo e(route("worker.spostamento")); ?>"><span class="m-auto">Spostamento merci</span></a>
          

      </div>
      <div class="w-100 py-3"></div>
      <div class="col">
          
        <a class="btn  btn_menu m-auto d-flex" href=""><span class="m-auto">WIP Ordini</span></a>

      </div>
      <div class="col">
        <a class="btn  btn_menu m-auto d-flex" href=""><span class="m-auto">WIP Delivery</span></a>
          

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danil\OneDrive\Desktop\progetti_kemedia\new_vegagel\resources\views/worker/home.blade.php ENDPATH**/ ?>